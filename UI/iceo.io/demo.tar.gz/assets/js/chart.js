var btn = document.getElementById('toggle');
var wrap = document.getElementById('wrap');
if(btn){
btn.addEventListener('click', function(e) {
  wrap.className = "";
  setTimeout(function() {
    wrap.className = "animated";
  },3000);
});}
setTimeout(function() {
  wrap.className = "animated";
},1000);